<div class="form-group">
  {!! Form::label('street_one', 'street_one:') !!}
  {!! Form::text('street_one',$street_one,['class'=>'form-control']) !!}
</div>
<div class="form-group">
  {!! Form::label('street_two', 'street_two:') !!}
  {!! Form::text('street_two',$street_two,['class'=>'form-control']) !!}
</div>
<div class="form-group">
  {!! Form::label('zipcode', 'zipcode:') !!}
  {!! Form::text('zipcode',$zipcode,['class'=>'form-control']) !!}
</div>